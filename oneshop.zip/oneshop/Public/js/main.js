$(document).ready(function(){
    $('.left_menu .menu-list').click(function(){
         $('.left_menu .menu-list').removeClass('active');
         $(this).addClass('active');
         
        $('.left_menu .menu-list .sub-menu-list').slideUp();
        $(this).children('.sub-menu-list').slideDown();
    })
})