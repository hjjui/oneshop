/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50051
Source Host           : localhost:3306
Source Database       : oneshop

Target Server Type    : MYSQL
Target Server Version : 50051
File Encoding         : 65001

Date: 2016-09-02 17:17:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `oneshop_access`
-- ----------------------------
DROP TABLE IF EXISTS `oneshop_access`;
CREATE TABLE `oneshop_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) default NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of oneshop_access
-- ----------------------------

-- ----------------------------
-- Table structure for `oneshop_admin`
-- ----------------------------
DROP TABLE IF EXISTS `oneshop_admin`;
CREATE TABLE `oneshop_admin` (
  `id` smallint(6) NOT NULL auto_increment,
  `username` varchar(16) default NULL,
  `password` varchar(32) default NULL,
  `email` varchar(100) default NULL,
  `created_time` int(11) default NULL,
  `logintime` int(11) default NULL,
  `loginip` int(10) default NULL,
  `status` tinyint(1) default NULL,
  `remark` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of oneshop_admin
-- ----------------------------
INSERT INTO `oneshop_admin` VALUES ('1', 'administrator', '455f72b8c728ba88f7fac75d3041dd02', '35698950@qq.com', '1472801271', '1472801271', null, '1', '超级管理员，有所有后台权限');

-- ----------------------------
-- Table structure for `oneshop_node`
-- ----------------------------
DROP TABLE IF EXISTS `oneshop_node`;
CREATE TABLE `oneshop_node` (
  `id` smallint(6) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) default NULL,
  `status` tinyint(1) default '0',
  `remark` varchar(255) default NULL,
  `sort` smallint(6) unsigned default NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of oneshop_node
-- ----------------------------

-- ----------------------------
-- Table structure for `oneshop_role`
-- ----------------------------
DROP TABLE IF EXISTS `oneshop_role`;
CREATE TABLE `oneshop_role` (
  `id` smallint(6) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) default NULL,
  `status` tinyint(1) unsigned default NULL,
  `remark` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of oneshop_role
-- ----------------------------

-- ----------------------------
-- Table structure for `oneshop_role_user`
-- ----------------------------
DROP TABLE IF EXISTS `oneshop_role_user`;
CREATE TABLE `oneshop_role_user` (
  `role_id` mediumint(9) unsigned default NULL,
  `user_id` char(32) default NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of oneshop_role_user
-- ----------------------------
