<?php
return array(

// 配置文件增加设置
// USER_AUTH_ON 是否需要认证
// USER_AUTH_TYPE 认证类型
// USER_AUTH_KEY 认证识别号
// REQUIRE_AUTH_MODULE  需要认证模块
// NOT_AUTH_MODULE 无需认证模块
// USER_AUTH_GATEWAY 认证网关
// RBAC_DB_DSN  数据库连接DSN
// RBAC_ROLE_TABLE 角色表名称
// RBAC_USER_TABLE 用户表名称
// RBAC_ACCESS_TABLE 权限表名称
// RBAC_NODE_TABLE 节点表名称
//RBAC设置
    "USER_AUTH_ON" => true,                    //是否开启权限验证(必配)
    "USER_AUTH_TYPE" => 1,                     //验证方式（1、登录验证；2、实时验证）

    "USER_AUTH_KEY" => 'uid',                  //用户认证SESSION标记(必配)
    "ADMIN_AUTH_KEY" => 'administrator',          //超级管理员识别号(必配)
    "USER_AUTH_MODEL" => 'admin',               //验证用户表模型 oneshop_admin
    'USER_AUTH_GATEWAY'  =>  '/Public/login',  //用户认证失败，跳转URL

    'AUTH_PWD_ENCODER'=>'md5',                 //默认密码加密方式

    "RBAC_SUPERADMIN" => 'admin',              //超级管理员名称


    "NOT_AUTH_MODULE" => 'Public',       //无需认证的控制器
    "NOT_AUTH_ACTION" => 'login,logout',     //无需认证的方法

    'REQUIRE_AUTH_MODULE' =>  '',              //默认需要认证的模块
    'REQUIRE_AUTH_ACTION' =>  '',              //默认需要认证的动作

    'GUEST_AUTH_ON'   =>  false,               //是否开启游客授权访问
    'GUEST_AUTH_ID'   =>  0,                   //游客标记

    "RBAC_ROLE_TABLE" => 'oneshop_role',            //角色表名称(必配)
    "RBAC_USER_TABLE" => 'oneshop_role_user',       //用户角色中间表名称(必配)
    "RBAC_ACCESS_TABLE" => 'oneshop_access',        //权限表名称(必配)
    "RBAC_NODE_TABLE" => 'oneshop_node',            //节点表名称(必配)

);