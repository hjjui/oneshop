<?php
return array(
    'content_manage'=>'内容',
    'artacle' => '文章管理',
    'category' => '分类管理',
);
