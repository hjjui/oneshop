<?php


/**
 * Description of BaseController
 *
 * @author zhuobing <35698950@qq.com>
 */
namespace Admin\Controller;
use Think\Controller;
use Org\Util\Rbac;
class BaseController extends Controller{
   /**
     * thinkphp专用的初始化函数 用了这个就不用在调用父类的构造函数了 parent::__construct();
     */
    protected function _initialize(){
        Rbac::checkLogin();
        if(!Rbac::AccessDecision()){
            $this->show("对不起，您没有权限");
        }
    }     
}
