<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PublicController
 *
 * @author zhuobing <35698950@qq.com>
 */
namespace Admin\Controller;
use Think\Controller;
use Org\Util\Rbac;
use Think\Verify;
class PublicController extends Controller{
    //put your code here
    public function login(){
       if(IS_POST){
           $username = I("post.username","");
           $password = I("post.password","",'md5');
           $verify_code = I("post.verify","");
           $verify = new Verify();
           if($verify->check($verify_code)){
                $admin = M('admin');
                $data = $admin->where("username = '$username' AND password = '$password'")->find();
                if(!empty($data)){
                    session(C('USER_AUTH_KEY'),$data);
                    if($data['username'] == 'administrator') session(C('ADMIN_AUTH_KEY'),true);
                    Rbac::saveAccessList();
                    $this->success("登录成功",U("Index/index"));
                }else{
                    $this->error("登录失败");
                }
           }else{
               $this->error("验证码错误");
           }
       }else{
           if(PublicController::is_login()){
               $this->redirect("Index/index");
           }
           $this->display(); 
           
       }        
    }
    public function logout(){
         session(C('USER_AUTH_KEY'),null);
         session(C('ADMIN_AUTH_KEY'),null);
         $this->success("退出成功",U("Index/index"));
    }
    public function verify(){
        $verify = new Verify();
        $verify->entry();
    } 
    public static function is_login(){
         $auth_user = session(C('USER_AUTH_KEY'));
         if(!$auth_user){
             return false;
         }else{
             return $auth_user;
         }
     }     
}
