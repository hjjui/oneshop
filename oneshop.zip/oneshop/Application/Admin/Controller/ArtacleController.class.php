<?php
namespace Admin\Controller;
class ArtacleController extends BaseController {
    public function index(){
        
        $this->display();
    }
}