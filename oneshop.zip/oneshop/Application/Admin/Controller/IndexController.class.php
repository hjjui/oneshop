<?php
namespace Admin\Controller;
class IndexController extends BaseController {
    public function index(){
        $this->display();
    }
}