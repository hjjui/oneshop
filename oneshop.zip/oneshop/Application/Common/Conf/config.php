<?php
return array(
    'SHOW_PAGE_TRACE' =>false, //开启trace调试信息
    'DATA_CACHE_PREFIX'=>'onepage', //缓存前缀
	//'配置项'=>'配置值'
	//'配置项'=>'配置值'
    'LOAD_EXT_CONFIG'=>'db',
    'TMPL_PARSE_STRING'  =>array(
        '__JS__'     => "/oneshop/Public/js/", // 增加新的JS类库路径替换规则
        '__UPLOAD__' => '/oneshop/Uploads', // 增加新的上传路径替换规则
        '__CSS__'     => '/oneshop/Public/css/', // 增加新的JS类库路径替换规则
    ),   
    
    //多语言支持的配置
    'LANG_SWITCH_ON' =>true,
    'LANG_AUTO_DETECT' => true, // 自动侦测语言 开启多语言功能后有效
    'LANG_LIST'        => 'zh-cn', // 允许切换的语言列表 用逗号分隔
    'VAR_LANGUAGE'     => 'l',     // 默认语言切换变量
    //开启日志记录 sql级别的日志只有在调试模式下才会记录
    'LOG_RECORD' => true, // 开启日志记录
    'LOG_LEVEL'  =>'EMERG,ALERT,CRIT,ERR', // 只记录EMERG ALERT CRIT ERR 错误   
    
    );