<?php
return array(
    'welcome'=>'欢迎使用ONESHOP',
    'login'=>'登录',
    'logout'=>'退出',
    'username'=>'用户名',
    'password'=>'密码',
    'remember_me'=>'记住用户名',
    'verify'=>'验证码',
);
