<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="http://cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="/oneshop/Public/css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="/oneshop/Public/js/main.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="http://cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    
    
    <style>
        .form-signin{
            max-width:330px;
            margin:0 auto;
        }
    </style>
  </head>
  
  <body>
    <div class="container">

        <form  class="form-signin" action="" method="post">
            <h2 class="form-signin-heading"><?php echo L('welcome');?></h2>
            <div class="form-group">
                <label class="sr-only"><?php echo L('username');?></label>
                <input name="username" type="text" class="form-control" placeholder="<?php echo L('username');?>" required autofocus>
            </div>
            <div class="form-group">
                <label class="sr-only"><?php echo L('password');?></label>
                <input name="password" type="password" class="form-control" placeholder="<?php echo L('password');?>" required>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-sm-7">
                         <input id='verify' name="verify" type="text" class="form-control" placeholder="<?php echo L('verify');?>" required>
                    </div>
                   <div class="col-sm-5">
                         <img src="<?php echo U('Public/verify');?>" class="img-responsive"/>
                   </div>                    
                </div>
            </div>
            
            <div class="checkbox">
              <label>
                <input type="checkbox" value="remember_me"> <?php echo L('remember_me');?>
              </label>
            </div>
            <button class="btn btn-lg btn-primary btn-block" type="submit"><?php echo L('login');?></button>
        </form>

    </div> <!-- /container -->
  </body>
</html>