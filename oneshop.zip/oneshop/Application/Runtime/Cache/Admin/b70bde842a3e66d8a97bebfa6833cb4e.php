<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="http://cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="/oneshop/Public/css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="http://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="/oneshop/Public/js/main.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="http://cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    
    
    <style>
        .form-signin{
            max-width:330px;
            margin:0 auto;
        }
    </style>
  </head>
  
<body>
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">ONESHOP</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="#">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Action</a></li>
                            <li><a href="#">Another action</a></li>
                            <li><a href="#">Something else here</a></li>
                            <li role="separator" class="divider"></li>
                            <li class="dropdown-header">Nav header</li>
                            <li><a href="#">Separated link</a></li>
                            <li><a href="#">One more separated link</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="../navbar/">Default</a></li>
                    <li class="active"><a href="./">Static top <span class="sr-only">(current)</span></a></li>
                    <li><a href="../navbar-fixed-top/">Fixed top</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div>
    </nav>

<div class="container-fluid">
    <div class="row main">
        <div class="col-xs-2 left_menu">
                            <nav>
                    <ul class="nav nav-pills nav-stacked left_menu">
                        <li class="menu-list" ><a href="javascript:;"><i class="fa fa-home"></i> <span><?php echo L('content_manage');?></span></a>
                            <ul class="sub-menu-list" style="display: none;">
                                <li class="active"><a href="<?php echo U('Artacle/index');?>"> <?php echo L('artacle');?></a></li>
                                <li><a href="<?php echo U('Category/index');?>"> <?php echo L('category');?></a></li>
                            </ul>
                        </li>
                        <li class="menu-list active"><a href="javascript:;"><i class="fa fa-laptop"></i> <span>Layouts</span></a>
                            <ul class="sub-menu-list" style="">
                                <li><a href="blank_page.html"> Blank Page</a></li>
                                <li><a href="boxed_view.html"> Boxed Page</a></li>
                                <li><a href="leftmenu_collapsed_view.html"> Sidebar Collapsed</a></li>
                                <li><a href="horizontal_menu.html"> Horizontal Menu</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
        </div>
        <div class="col-xs-10 content">
            
    <h3>文章列表<small>（对文章进行添加、编辑、删除等操作）</small></h3>

        </div>
    </div>
</div>
</body>
</html>